package com.hibernate.demo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.hibernate.demo.entity.Instructor;
import com.hibernate.demo.entity.InstructorDetail;
import com.hibernate.demo.entity.Student;

public class DeleteInstructorDetailDemo {

	public static void main(String[] args) {

		// create session factory
		
		SessionFactory factory= new Configuration().configure("hibernate.cfg.xml").
				addAnnotatedClass(Instructor.class).
				addAnnotatedClass(InstructorDetail.class).buildSessionFactory();
		
		//create session
		Session session= factory.getCurrentSession();
		
		try {
			//use the session object to save the java object
			
//start the transacttion	
			session.beginTransaction();
		
			
			//get instructor by primary key/ if
			
			int theId=3;
			InstructorDetail tempInstructorDetail=session.get(InstructorDetail.class, theId);
			System.out.println("found instructor: "+tempInstructorDetail);
		//Note: will also delete associate details object
			//because of cascade type all
			
			// Remove the associated object reference
			// break bi-direnctional link
			
			tempInstructorDetail.getInstructor().setInstructorDetail(null);
			System.out.println("deleting "+ tempInstructorDetail);
		session.delete(tempInstructorDetail);
				
				
				
			//commiit transaction
			session.getTransaction().commit();
			System.out.println("Done!");
			
		} catch (Exception e) {
			session.close();
			factory.close();
		}
	}

}
