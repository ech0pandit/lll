package com.hibernate.demo;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.hibernate.demo.entity.Student;

public class QueryStudentDemo {

	public static void main(String[] args) {

		// create session factory
		
		SessionFactory factory= new Configuration().configure("hibernate.cfg.xml").
				addAnnotatedClass(Student.class).buildSessionFactory();
		
		//create session
		Session session= factory.getCurrentSession();
		
		try {
			//use the session object to save the java object
			
	
			//start a transaction
			session.beginTransaction();
			
		//query students
			List<Student> theStudents=session.createQuery("from Student").list();
			
			displayStudents(theStudents);
			
			//query students: lastname='duck'
			theStudents=session.createQuery("from Student s where s.lastName='duck'").list();
			
			//display the students
			System.out.println("\n\n Students whose name ends with duck");
			displayStudents(theStudents);
			
			//query students: lastname='duck' or firstname 'nitish'
			theStudents=
					session.createQuery("from Student s where s.lastName='duck' Or "
							+ "s.firstName='Nitish'" ).list();
			displayStudents(theStudents);
			
			
			//query students where email Like '%dd@t.com'
			theStudents=
					session.createQuery("from Student s where s.email Like '%dd@t.com'" ).list();
			displayStudents(theStudents);
			
			//
			
			
			//commiit transaction
			session.getTransaction().commit();
			System.out.println("Done!");
			
		} catch (Exception e) {
			factory.close();
		}
	}

	private static void displayStudents(List<Student> theStudents) {
		for (Student tempStudent:theStudents)
		{
			System.out.println(tempStudent);
		}
	}

}
